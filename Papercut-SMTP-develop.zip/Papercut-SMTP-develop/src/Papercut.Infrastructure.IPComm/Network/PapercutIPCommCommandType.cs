namespace Papercut.Infrastructure.IPComm.Network
{
    public enum PapercutIPCommCommandType
    {
        NoOp = 0,

        Publish = 1,

        Exchange = 2
    }
}
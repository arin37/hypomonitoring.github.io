namespace Papercut.Common.Domain
{
    public interface IMessage { }
}